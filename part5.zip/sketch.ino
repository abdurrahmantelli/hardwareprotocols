#include "FS.h"
#include "SD.h"
#include "SPI.h"

// Donanım Sabitleri
const int PIN_SD_CS = 5;
const char* BLACKBOX = "/TELEMETRY.CSV";

void setup() {
  Serial.begin(115200);
  while(!Serial);

  // 1. SPI Veriyolunu Başlat (SCK, MISO, MOSI, CS)
  SPI.begin(18, 19, 23, PIN_SD_CS);
  Serial.println("\n[SD] SPI Başlatıldı. SD Kart aranıyor...");

  // 2. SD Kartı Mount Etme
  if (!SD.begin(PIN_SD_CS)) {
    Serial.println("[OBD!] HATA: SD kart takılı değil veya bağlantı hatası! (CS=IO5?)");
    return;
  }
  
  Serial.println("[SD] Kart OK — Karakutu dosya sistemi aktif.");
  
  // 3. Dosya Yoksa Başlık Satırını Yaz
  if (!SD.exists(BLACKBOX)) {
    File f = SD.open(BLACKBOX, FILE_WRITE);
    if (f) {
      f.println("timestamp,rpm,hiz,engT,cabT,fuel,dtc");
      f.close();
      Serial.println("[SD] Yeni kara kutu dosyası oluşturuldu, başlık atıldı.");
    }
  }

  // --- GERÇEK TEST: YAZMA VE OKUMA ---
  Serial.println("\n--- TEST BAŞLIYOR ---");
  
  // A. Karta sahte bir veri satırı yazalım
  blackboxLog(3200, 90, 92, 24.5, 63, "P0100");
  
  // B. Karttan veriyi geri okuyup kanıtı basalım
  blackboxDump();
  
  Serial.println("--- TEST TAMAMLANDI ---\n");
}

void loop() {
  // Normal çalışma anında burada sensör verileri okunup periyodik yazılır.
  // Örn: Her 1 saniyede bir blackboxLog(...) çağrılabilir.
  delay(10000); 
}

// --- Kayıt Fonksiyonu (Yazma Mantığı) ---
void blackboxLog(uint16_t rpmV, uint8_t hizV, uint8_t engTV,
                 float cabTV, uint8_t fuelV, const char* dtcV) {
  
  // Simamine edilmiş zaman damgası
  uint16_t y = 2026; uint8_t m = 10, d = 25, h = 16, min = 45, s = 0;

  // FILE_APPEND: İmleci dosya sonuna götürür, veriyi ekler (öncekileri silmez)
  File f = SD.open(BLACKBOX, FILE_APPEND);
  if (!f) {
    Serial.println("[SD] Yazma hatası! Dosya ekleme modunda açılamadı.");
    return;
  }

  // CSV formatında biçimlendirilmiş satırı karta bas
  f.printf("%04u-%02u-%02uT%02u:%02u:%02u,%u,%u,%u,%.1f,%u,%s\n",
           y, m, d, h, min, s,
           rpmV, hizV, engTV, cabTV, fuelV, dtcV);
           
  f.close(); // Buffer'ı karta fiziksel olarak flush et ve dosyayı kapat
  Serial.println("[SD] 1 satır veri başarıyla kara kutuya yazıldı.");
}

// --- Geri Okuma Fonksiyonu (Okuma Mantığı) ---
void blackboxDump() {
  // FILE_READ: Dosyayı baştan okumak üzere açar
  File f = SD.open(BLACKBOX, FILE_READ);
  if (!f) {
    Serial.println("[SD] Okuma hatası! Dosya bulunamadı.");
    return;
  }

  Serial.println("==== KARA KUTU İÇERİĞİ (DUMP) ====");
  // f.available(): Dosya sonuna (EOF) gelene kadar true döner
  while (f.available()) {
    Serial.write(f.read()); // Karakter karakter okuyup seri monitöre basar
  }
  Serial.println("==================================");
  f.close();
}