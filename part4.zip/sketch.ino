#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <RTClib.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP085.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

RTC_DS1307 rtc;
Adafruit_BMP085 bmp;

void i2cScan() {
  Serial.println("[I2C] Hat taraniyor...");
  uint8_t n = 0;
  for (uint8_t a = 1; a < 127; a++) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) {
      Serial.printf("  -> 0x%02X adresinde cihaz var\n", a);
      n++;
    }
  }
  Serial.printf("[I2C] %u cihaz bulundu (beklenen: 0x3C, 0x68, 0x77)\n", n);
}

void setup() {
  Serial.begin(115200);
  delay(1000);

  Wire.begin(21, 22);
  i2cScan();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("[OBD!] OLED bulunamadi (0x3C?)");
  } else {
    display.clearDisplay();
    display.setTextColor(SSD1306_WHITE);
    display.setTextSize(1);
    display.setCursor(0, 28);
    display.print("OBD-II GATEWAY");
    display.display();
  }

  if (!rtc.begin()) {
    Serial.println("[OBD!] DS1307 bulunamadi (0x68?)");
  } else if (!rtc.isrunning() || rtc.now().year() < 2020) {
    rtc.adjust(DateTime(F(__DATE__), F(__TIME__)));
  }

  if (!bmp.begin()) {
    Serial.println("[OBD!] BMP180 bulunamadi (0x77?)");
  }
}

void loop() {
  DateTime now = rtc.now();
  float kabinC = bmp.readTemperature();
  int32_t pa   = bmp.readPressure();

  Serial.printf("Saat: %02u:%02u:%02u | Kabin Sicakligi: %.2f C | Basinc: %d Pa\n", 
                now.hour(), now.minute(), now.second(), kabinC, (int)pa);

  delay(1000);
}