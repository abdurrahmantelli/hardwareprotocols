const uint8_t  PIN_POT      = 34;       // Potansiyometre pini (Gaz pedalı simülasyonu)
const uint8_t  CAN_SYNC     = 0xAA;     // Senkron baytı
const uint16_t ID_OBD_TESTER = 0x07E0;  // Sorgu ID'si (Test cihazı)
const uint16_t ID_OBD_ECU    = 0x07E8;  // Yanıt ID'si (ECU)

uint32_t canTxCount = 0, canRxCount = 0, canErrCount = 0; // Hat sağlığı sayaçları
float gaz = 0, rpm = 800;
uint32_t tQ = 0;

// İleri bildirimler (Forward declarations)
void canSend(uint16_t id, const uint8_t* data, uint8_t len);
void ecuOnQuery();
void canTick();

void setup() {
  Serial.begin(115200);
  Serial2.begin(500000, SERIAL_8N1, 16, 17); // UART2 (CAN Kablosu simülasyonu: RX=16, TX=17)
  pinMode(PIN_POT, INPUT);
  Serial.println("[SISTEM] Adım 3 - CAN Çerçeve Katmanı Başlatıldı.");
}

void canSend(uint16_t id, const uint8_t* data, uint8_t len) {
  uint8_t sum = 0;
  
  Serial2.write(CAN_SYNC); sum += CAN_SYNC;          // 1) Senkron baytı
  uint8_t idH = id >> 8, idL = id & 0xFF;
  Serial2.write(idH); sum += idH;                    // 2) ID üst baytı
  Serial2.write(idL); sum += idL;                    // 3) ID alt baytı
  Serial2.write(len);  sum += len;                   // 4) Uzunluk (DLC)
  
  for (uint8_t i = 0; i < len; i++) {                // 5) Veri baytları
    Serial2.write(data[i]); sum += data[i];
  }
  
  Serial2.write((uint8_t)(0 - sum));                 // 6) 2'li tümleyen checksum
  canTxCount++;
}

enum CanRxState { CAN_SYNC_WAIT, CAN_IDH, CAN_IDL, CAN_DLC, CAN_DATA, CAN_CHK };
CanRxState canRx = CAN_SYNC_WAIT;
uint16_t   canIdBuf;
uint8_t    canDlcBuf, canDataBuf[8], canDataIdx, canSumBuf;

void canTick() {
  while (Serial2.available()) {
    uint8_t b = Serial2.read();
    switch (canRx) {
      case CAN_SYNC_WAIT:
        if (b == CAN_SYNC) { canSumBuf = b; canRx = CAN_IDH; }
        break;
      case CAN_IDH: 
        canIdBuf  = (uint16_t)b << 8; 
        canSumBuf += b; 
        canRx = CAN_IDL; 
        break;
      case CAN_IDL: 
        canIdBuf |= b; 
        canSumBuf += b; 
        canRx = CAN_DLC;  
        break;
      case CAN_DLC:
        canDlcBuf = b; 
        canSumBuf += b;
        if (b <= 8) { canDataIdx = 0; canRx = CAN_DATA; }
        else        { canRx = CAN_SYNC_WAIT; } // İmkansız uzunluk -> çöp
        break;
      case CAN_DATA:
        canDataBuf[canDataIdx++] = b; 
        canSumBuf += b;
        if (canDataIdx >= canDlcBuf) canRx = CAN_CHK;
        break;
      case CAN_CHK:
        canSumBuf += b;
        if (canSumBuf == 0) {
          canRxCount++;
          // Multicast: İşi olan ID'yi yakalar
          if (canIdBuf == ID_OBD_TESTER) ecuOnQuery(); 
          if (canIdBuf == ID_OBD_ECU) {
            Serial.printf("[CAN RX] ID=0x%04X  %02X %02X %02X %02X %02X %02X %02X %02X\n",
                          (unsigned)canIdBuf, canDataBuf[0], canDataBuf[1],
                          canDataBuf[2], canDataBuf[3], canDataBuf[4],
                          canDataBuf[5], canDataBuf[6], canDataBuf[7]);
          }
        } else {
          canErrCount++;
          Serial.printf("[CAN] CHECKSUM HATASI (ID=0x%04X) -> çerçeve atıldı\n", (unsigned)canIdBuf);
        }
        canRx = CAN_SYNC_WAIT;
        break;
    }
  }
}

void ecuOnQuery() {
  uint8_t resp[8];
  uint16_t raw = (uint16_t)(rpm * 4); // OBD-II kuralı: RPM = raw / 4
  resp[0] = 0x04; resp[1] = 0x41; resp[2] = 0x0C; // OBD yanıt başlığı
  resp[3] = raw >> 8; resp[4] = raw & 0xFF;       // RPM (2 bayt)
  resp[5] = 0; resp[6] = 0; resp[7] = 0;          
  canSend(ID_OBD_ECU, resp, 8);
}

void loop() {
  gaz = analogRead(PIN_POT) * 100.0f / 4095.0f;
  rpm = 800 + (gaz * 60);

  canTick(); // Hattı asla aç bırakma!

  // 5 saniye sonra bilerek bozuk çerçeve gönderme testi (Sağlamlık dersi)
  static bool bozukGitti = false;
  if (!bozukGitti && millis() > 5000) {
    bozukGitti = true;
    uint8_t bad[] = { 0xAA, 0x07, 0xE8, 0x08, 1, 2, 3, 4, 5, 6, 7, 8, 0x00 };
    Serial2.write(bad, sizeof(bad)); // Sağlaması bilerek yanlış!
    Serial.println("[TEST] Bilerek bozuk çerçeve gönderildi");
  }

  if (millis() - tQ >= 200) { // 200 ms'de bir OBD-II sorgusu
    tQ = millis();
    uint8_t q[8] = { 0x02, 0x01, 0x0C, 0, 0, 0, 0, 0 }; // "RPM nedir?"
    canSend(ID_OBD_TESTER, q, 8);
  }
  
  delay(2);
}