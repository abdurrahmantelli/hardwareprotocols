const int PIN_POT    = 34;   
const int PIN_CAN_RX = 16;   
const int PIN_CAN_TX = 17;   

void setup() {
  Serial.begin(115200);                                     
  Serial2.begin(115200, SERIAL_8N1, PIN_CAN_RX, PIN_CAN_TX); 
}

void loop() {
  int   ham = analogRead(PIN_POT);           
  float gaz = (float)ham * 100.0f / 4095.0f; 
  float rpm = 800.0f + gaz * 60.0f;          

  Serial2.printf("RPM:%.0f,GAZ:%.0f\n", rpm, gaz);

  // --- DÜZELTİLEN KISIM: Satır bazlı okuma ---
  if (Serial2.available()) {
    String gelen = Serial2.readStringUntil('\n');
    Serial.print("HATTAN GELEN: ");
    Serial.println(gelen);
  }
  
  delay(200);
}